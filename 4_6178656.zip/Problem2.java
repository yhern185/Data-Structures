import java.io.IOException;
import java.util.ArrayList;

/****************************************************************
 * Purpose/Description: This program implements the radixSort algorithm
 *      to sort in increasing order an array of integer positive keys.
 *      Implementation consider that each key contains only even digits
 *      if program detect odd digits it will abort abort.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      the Input Array is given.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************/

public class Problem2
{
    public static final int[] INPUT_ARRAY = {2, 4, 4, 8, 6, 24, 4, 364, 2004, 44, 66666666};
    public static final int INDEX_0 = 0;
    public static final int INDEX_1 = 1;
    public static final int TWO = 2;
    public static final int INCREASE_DECIMAL_PLACES = 10;
    public static final int AMOUNT_OF_DIGITS = 10;

    public static void main (String[] args)
    {
        try
        {
            int maxNumber = findMaxNUmber();
            int numberOfDigits = findNumberOfDigits(maxNumber);
            ArrayList<Integer> sortedInput = sortInput(numberOfDigits);
            System.out.println(sortedInput.toString());

        }catch (IOException exception)
        {
            System.out.println(exception.getMessage());
        }
    }

    /**------------------------------ sortInput ----------------------------
     |  Method sortInput(int numberOfDigits)
     |
     |Purpose: This method sort a given array using the radix sort method.
     |  It will iterate as many times as the number of digits of the maximum
     |  integer found on the INPUT_ARRAY.
     |
     |  Creates an array of size 10 and on each position contains an array list
     |  storing the number of occurrences found for each digit.
     |
     |  @param maxNumber
     |
     | @return sortedArray
     *-------------------------------------------------------------------**/
    private static ArrayList<Integer> sortInput(int numberOfDigits) throws IOException
    {
        ArrayList<Integer>[] storeArray = new ArrayList[AMOUNT_OF_DIGITS];
        ArrayList<Integer> sortedArray = new ArrayList<>();
        int decimalPlaces = INDEX_1;

        for(int storeArrayIndex = INDEX_0; storeArrayIndex < storeArray.length; storeArrayIndex++)
        {
            storeArray[storeArrayIndex] = new ArrayList<>();
        }

        for(int inputArrayIndex = INDEX_0; inputArrayIndex < INPUT_ARRAY.length; inputArrayIndex++)
        {
            sortedArray.add(INPUT_ARRAY[inputArrayIndex]);
        }

        for(int numberOfDigitsIndex = INDEX_0; numberOfDigitsIndex < numberOfDigits; numberOfDigitsIndex++)
        {
            for(int sortedArrayIndex = INDEX_0; sortedArrayIndex < sortedArray.size(); sortedArrayIndex++)
            {
                if(((sortedArray.get(sortedArrayIndex)/ decimalPlaces) % TWO) != INDEX_0)
                {
                    throw new IOException ("*** Abort *** the input has at least one key with odd digits");
                }
                storeArray[(sortedArray.get(sortedArrayIndex)/ decimalPlaces) % INCREASE_DECIMAL_PLACES].add(sortedArray.get(sortedArrayIndex));
            }
            sortedArray.clear();
            decimalPlaces *= INCREASE_DECIMAL_PLACES;

            for(int storeArrayIndex = INDEX_0; storeArrayIndex < storeArray.length; storeArrayIndex++)
            {
                sortedArray.addAll(storeArray[storeArrayIndex]);
                storeArray[storeArrayIndex].clear();
            }
        }
        return sortedArray;
    }

    /**------------------------------ findNumberOfDigits ----------------------------
     |  Method findNumberOfDigits(int maxNumber)
     |
     |Purpose: This method finds the number of digits on the maximum number
     |  found in the given array.
     |
     |  @param maxNumber
     |
     | @return numberOfDigits
     *-------------------------------------------------------------------**/
    private static int findNumberOfDigits(int maxNumber)
    {
        int decimalPlaces = INCREASE_DECIMAL_PLACES;
        int numberOfDigits = INDEX_1;

        while((maxNumber / decimalPlaces) > INDEX_0)
        {
            numberOfDigits++;
            decimalPlaces *= INCREASE_DECIMAL_PLACES;
        }

        return numberOfDigits;
    }

    /**------------------------------ findMaxNUmber ----------------------------
     |  Method findOddNumbers()
     |
     |Purpose: This method finds the maximum integer in a given array.
     |
     |  @param none
     |
     | @return maxNumber
     *-------------------------------------------------------------------**/
    private static int findMaxNUmber()
    {
        int maxNumber = INPUT_ARRAY[INDEX_0];
        for(int inputArrayIndex = INDEX_1; inputArrayIndex < INPUT_ARRAY.length; inputArrayIndex++)
        {
            if(INPUT_ARRAY[inputArrayIndex] > maxNumber)
            {
                maxNumber = INPUT_ARRAY[inputArrayIndex];
            }
        }
        return maxNumber;
    }
}


/**------------------------------ SUBSECTION (B) ----------------------------
 *  What is the running time complexity of your radixSort method? Justify.
 *
 *  This program uses BucketSort one digit at the time were the number of
 *  buckets equals the radix. Starting for the LSD (Least Significant Digit)
 *  do one pass at the time per digit to MSD (Most Significant Digit). The
 *  number of passes is determined by the size of th longer element. Therefore,
 *  the running time complexity can be determined by O( d * ( n + k )).
 *
 *
 *-------------------------------------------------------------------------**/