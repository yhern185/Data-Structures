import java.util.ArrayList;

/****************************************************************
 * Purpose/Description: This program accepts an array of integers,
 *      implement the moveAllNegativeOne method to move all -1
 *      present in the array to the end. The algorithm maintain
 *      the relative order of items in the array and the worst-case
 *      running time complexity is linear.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      the Input Array is given.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************/

public class Problem1
{
    public static final int[] INPUT_ARRAY = {6, -1, 8, 2, 3, -1, 4, -1, 1};
    public static final int INDEX_0 = 0;
    public static final int NEGATIVE_ONE = -1;

    public static void main(String[] args)
    {
        ArrayList<Integer> negativesAtTheEnd = moveAllNegativeOne();
        System.out.println(negativesAtTheEnd.toString());
    }

    /**------------------------------ moveAllNegativeOne ----------------------------
     |  Method moveAllNegativeOne()
     |
     |Purpose: Move all negative 1s into another array keeping its precedence.
     |  Procedure is linear since visit all the elements exactly once on each
     |  for loop.
     |
     |  @param none
     |
     | @return negativesAtTheEnd
     *-------------------------------------------------------------------**/
    private static ArrayList<Integer> moveAllNegativeOne()
    {
        ArrayList<Integer> negativesAtTheEnd = new ArrayList<>();
        ArrayList<Integer> negativesOnes = new ArrayList<>();

        for(int inputArrayIndex = INDEX_0; inputArrayIndex < INPUT_ARRAY.length; inputArrayIndex++)
        {
            if(INPUT_ARRAY[inputArrayIndex] != NEGATIVE_ONE)
            {
                negativesAtTheEnd.add(INPUT_ARRAY[inputArrayIndex]);
            }
            else
            {
                negativesOnes.add(INPUT_ARRAY[inputArrayIndex]);
            }
        }

        negativesAtTheEnd.addAll(negativesOnes);

        return negativesAtTheEnd;
    }

}
