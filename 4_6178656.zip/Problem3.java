/****************************************************************
 * Purpose/Description: This program implements the merge sort
 *      algorithm without using recursion.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      the Input Array is given.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************/

public class Problem3
{
    public static final int INDEX_0 = 0;
    public static final int HALF = 2;
    public static final int SINGLE_ELEMENT = 1;

    public static void main (String[] args)
    {
        int[] inputArray = {90, 8, 7, 56, 123, 235, 9, 1, 653};
        int[] sortedInput = iterativeMergeSort(inputArray);

        for(int sortedArrayIndex : sortedInput)
        {
            System.out.print(sortedArrayIndex + " ");
        }
    }

    /**------------------------------ iterativeMergeSort ----------------------------
     |  Method sortInput(int numberOfDigits)
     |
     |Purpose: This method sort a given array using the merge sort algorithm in an
     |  iterative way. Keeps dividing the size of the problem by powers of 2 until
     |  it reaches size 1. In order to do so creates auxiliary arrays to store
     |  the left and right side of the original array respectively. After it reaches
     |  the size of 1 use for loops to merge the small arrays.
     |
     |  @param inputArray
     |
     | @return inputArray
     *----------------------------------------------------------------------------**/
    private static int[] iterativeMergeSort(int[] inputArray)
    {
        if(inputArray.length > SINGLE_ELEMENT)
        {
            int middlePoint = (inputArray.length / HALF);

            int[] leftArray = new int[middlePoint];
            for(int leftIndex = INDEX_0; leftIndex < middlePoint; leftIndex++)
            {
                leftArray[leftIndex] = inputArray[leftIndex];
            }

            int[] rightArray = new int[inputArray.length - middlePoint];
            for(int rightIndex = middlePoint; rightIndex < inputArray.length; rightIndex++)
            {
                rightArray[rightIndex - middlePoint] = inputArray[rightIndex];
            }

            iterativeMergeSort(leftArray);
            iterativeMergeSort(rightArray);

            int leftIndex = INDEX_0;
            int rightIndex = INDEX_0;
            int inputArrayIndex = INDEX_0;

            while(leftIndex < leftArray.length && rightIndex < rightArray.length)
            {
                if(leftArray[leftIndex] < rightArray[rightIndex])
                {
                    inputArray[inputArrayIndex] = leftArray[leftIndex];
                    leftIndex++;
                }
                else
                {
                    inputArray[inputArrayIndex] = rightArray[rightIndex];
                    rightIndex++;
                }
                inputArrayIndex++;
            }

            while(leftIndex < leftArray.length)
            {
                inputArray[inputArrayIndex] = leftArray[leftIndex];
                leftIndex++;
                inputArrayIndex++;
            }
            while(rightIndex < rightArray.length)
            {
                inputArray[inputArrayIndex] = rightArray[rightIndex];
                rightIndex++;
                inputArrayIndex++;
            }
        }
        return inputArray;
    }
}

