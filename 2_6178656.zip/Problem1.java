import java.util.LinkedList;

/**************************************************************************
 * Purpose/Description: This program implement the following methods from
 *      MyList data structure:
 *
 *      myPush(x): Insert item x on the front end of the MyList.
 *      myPop(): Remove the front item from the MyList and return it.
 *      myInject(x): Insert item x on the rear end of the MyList.
 *
 *      Using a double linked list will do the operations in constant time:
 *      O(1).
 *
 *      **NOTE**
 *      We use a DLL (Double Linked List) to be able to insert in constant
 *      time at the end, in order to do so, every node uses and additional
 *      pointer to track the previous element. *
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of it is the work
 *      of any other person.
 ***************************************************************************/

public class Problem1
{

    public LinkedList<Integer> integerLinkedList;

    /*------------------------------ myPush ---------------------------------
         |  Method myPush(int newElement)
         |
         |Purpose: Insert one element at the beginning of the double link list.
         |
         |  @param newElement
         |
         | @return none
         *-------------------------------------------------------------------*/
    void myPush(int newElement)
    {
        integerLinkedList.addFirst(newElement);
    }


    /*------------------------------ myPop ----------------------------------
         |  Method myPop()
         |
         |Purpose: Delete first element at the beginning of the double link list.
         |
         |  @param none
         |
         | @return none
         *-------------------------------------------------------------------*/
    void myPop()
    {
        integerLinkedList.removeFirst();
    }


    /*------------------------------ myInject ---------------------------------
         |  Method myInject(int newElement)
         |
         |Purpose: Insert one element at the end of the double link list.
         |
         |  @param newElement
         |
         | @return none
         *-------------------------------------------------------------------*/
    void myInject(int newElement)
    {
        integerLinkedList.addLast(newElement);
    }

}
