import java.util.ArrayList;

/**************************************************************************
 * Purpose/Description: In this problem, program only implements some
 *      simple operations for a binary search trees where keys are integers.
 *      It Assumes that the following code is given and the method bodies,
 *      even though not shown, are correct and implement the operations as
 *      were defined in class.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of it is the work
 *      of any other person.
 ***************************************************************************/

public class Problem2
{
    public static final int NO_VALUE = 0;

    public class BinarySearchTreeNode
    {

        public int key;
        public BinarySearchTreeNode left;
        public BinarySearchTreeNode right;
    }
    public class BinarySearchTree
    {
        private BinarySearchTreeNode root;
        public void insert(int key) { ... }
        public void delete(int key) { ... }
        public boolean find(int key) { ... }

        /***************Subsection A
        /*------------------------------ keySum ---------------------------------
         |  Method keySum()
         |
         |Purpose: Find the sum of all the keys in the tree. Uses a helper method.
         |  to find the sum by a recursive method that calls itself until reach
         |  the base case, in this case the base case is when the element do not
         |  exist (null)
         |
         |  @param none
         |
         | @return totalSum
         *-------------------------------------------------------------------*/
        public int keySum()
        {
            int totalSum = addHelper(root);
            return totalSum;
        }

        /**------------------------------ addHelper ---------------------------------
             |  Method addHelper(BinarySearchTreeNode node)
             |
             |Purpose: Helper method that use a recursive implementation to find to
             |  total value of the integers (keys) in the nodes.
             |
             |  @param node
             |
             | @return add
             *-------------------------------------------------------------------*/
        int addHelper(BinarySearchTreeNode node)
        {
            if (node != null)
            {
                int add = node.key;
                add += addHelper(node.left);
                add += addHelper(node.right);
                return add;
            }
            return NO_VALUE;
        }

        /**********Subsection B
        /*------------------------------ deleteMax ---------------------------------
         |  Method deleteMax()
         |
         |Purpose: Deletes maximum value (key) in the Binary Search Tree. Use provided
         |  method public void delete(int key) { ... } and we assume it is implemented
         |  corrected. In the BST the maximum element is the rightmost one, so first
         |  the method look is there is any root. Then creates an object of the BST
         |  class an it is used as temporal maximum until there is no more right child.
         |
         |  @param none
         |
         | @return none
         *-------------------------------------------------------------------*/
        public void deleteMax()
        {
            if(root == null)
            {
                System.out.println("No elements on the BST");
                return;
            }
            BinarySearchTreeNode temporalMaximum = root;
            while(temporalMaximum.right != null)
            {
                temporalMaximum = temporalMaximum.right;
            }
            delete(temporalMaximum.key);
        }

        /**************Subsection C
         /*------------------------------ printTree ---------------------------------
         |  Method printTree()
         |
         |Purpose: Prints the values in the BST in decreasing order.
         |  First see if there is any element in the tree checking the root. Second use a
         |  recursive method that goes to the rightmost element which is the maximum
         |  value and at last prints the leftmost element which is the minimum.
         |
         |  @param none
         |
         | @return none
         *-------------------------------------------------------------------*/
        public void printTree()
        {
            ArrayList<Integer> decreasingOrderKeys = new ArrayList<>();
            BinarySearchTreeNode tempRoot = root;

            if(root == null)
            {
                System.out.println("No elements in the BST");
                return;
            }
            decreasingOrderKeys = saveMaximum(tempRoot, decreasingOrderKeys);
            System.out.println(decreasingOrderKeys.toString());
        }

        /**------------------------------ saveMaximum ---------------------------------
         |  Method saveMaximum(BinarySearchTreeNode root, ArrayList<Integer> decreasingOrderKeys)
         |
         |Purpose: Private method to be used as helper for the printTree method in order
         |  to save all the values in a BST in decreasing order. Use recursion to go
         |  through every element of the tree where the base case if if there is no
         |  root. (root = null)
         |
         |  @param tempRoot
         |  @param decreasingOrderKeys
         |
         | @return decreasingOrderKeys
         *-------------------------------------------------------------------*/
        private ArrayList<Integer> saveMaximum(BinarySearchTreeNode tempRoot, ArrayList<Integer> decreasingOrderKeys)
        {
            if(tempRoot == null)
            {
                return decreasingOrderKeys;
            }
            if(tempRoot.right != null)
            {
                tempRoot = tempRoot.right;
                decreasingOrderKeys = saveMaximum(tempRoot, decreasingOrderKeys)
            }
            decreasingOrderKeys.add(tempRoot.key);
            tempRoot = tempRoot.left;
            decreasingOrderKeys = saveMaximum(tempRoot, decreasingOrderKeys);

            return decreasingOrderKeys;
        }

        /****************Subsection D
        /*------------------------------ printPreorder ---------------------------------
         |  Method printPreorder()
         |
         |Purpose: Prints the values in the BST in pre-order.
         |  First see if there is any element in the tree checking the root. Second use a
         |  recursive method that goes through every node.
         |  ***NOTE****
         |  Pre-Order : root ---> most left subtree ---> most right subtree
         |
         |  @param none
         |
         | @return none
         *------------------------------------------------------------------------*/
        public void printPreorder()
        {
            ArrayList<Integer> preorderKeys = new ArrayList<>();
            BinarySearchTreeNode tempRoot = root;

            if(root == null)
            {
                System.out.println("No elements in the BST");
                return;
            }
            preorderKeys = savePreorder(tempRoot, preorderKeys);
            System.out.println(preorderKeys.toString());

        }

        /**------------------------------ saveMaximum ---------------------------------
         |  Method savePreorder(BinarySearchTreeNode tempRoot, ArrayList<Integer> preorderKeys)
         |
         |Purpose: Private method to be used as helper for the printPreorder() method in order
         |  to save all the values in a BST in pre-order. Use recursion to go
         |  through every element of the tree where the base case if if there is no
         |  root. (root = null)
         |  Pre-Order : root ---> most left subtree ---> most right subtree
         |
         |  @param tempRoot
         |  @param preorderKeys
         |
         | @return preorderKeys
         *-------------------------------------------------------------------*/
        private ArrayList<Integer> savePreorder(BinarySearchTreeNode tempRoot, ArrayList<Integer> preorderKeys)
        {
            if(tempRoot == null)
            {
                return preorderKeys;
            }
            preorderKeys.add(tempRoot.key);
            if(root.left != null)
            {
                tempRoot = tempRoot.left;
            }
            else
            {
                tempRoot = tempRoot.right;
            }
            preorderKeys = savePreorder(tempRoot, preorderKeys);

            return preorderKeys;
        }

    }

}
