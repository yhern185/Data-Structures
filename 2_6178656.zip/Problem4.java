/**************************************************************************
 * Purpose/Description: The method will replace the first occurrence of oldKey
 *  with the newKey, and restore the Min-Heap property after the change. If the
 *  oldKey does not exist in the heap, the method prints an appropriate message
 *  and returns without changing the heap.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of it is the work
 *      of any other person.
 ***************************************************************************/

public class Problem4
{
     final int INDEX_0 = 0;
     final int HALF = 2;
     int[] minHeap = {0, 4, 6, 7, 32, 19, 64, 26, 99, 42, 54, 28};

    /***************Subsection C
     /**------------------------------ replaceKey ---------------------------------
     |  Method replaceKey(Integer oldKey, Integer newKey)
     |
     |Purpose: Method accepts 2 parameters, the old value and the new one to be inserted.
     |  First it will look for the old value in the existing Min-Heap tree, if it is
     |  present it will be removed. Otherwise will prompt a message letting the user
     |  know that it is not there. If old value is found the will be replace it by the
     |  new one and after that the heap will be restore. Uses a flag to notify is the
     |  value is present or not.
     |
     |  @param oldKey
     |  @param newKey
     |
     | @return none
     *-------------------------------------------------------------------*/
    public void replaceKey(Integer oldKey, Integer newKey)
    {
        boolean isFound = false;
        int replaceIndex = INDEX_0;
        for (int minHeapIndex = INDEX_0; minHeapIndex < minHeap.length; minHeapIndex++)
        {
            if (minHeap[minHeapIndex] == oldKey)
            {
                isFound = true;
                replaceIndex = minHeapIndex;
                minHeapIndex = minHeap.length;
            }
        }
        if (isFound)
        {
            minHeap[replaceIndex] = newKey;
            for (int minHeapIndex = (minHeap.length / HALF); minHeapIndex > INDEX_0; minHeapIndex--)
            {
                percolateDown(newKey);//Assuming percolateDown is given.
            }
        }
        else
        {
            System.out.println("Old Key not present in the Min-Heap.");
        }
    }
}
