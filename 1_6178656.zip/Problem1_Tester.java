/****************************************************************
 * Purpose/Description: This program finds all dominant elements
 *      in an array in a linear running time complexity
 *      Note:
 *      An element is a dominant element if is greater than all
 *      the elements to its right side. The rightmost element in
 *      the array is always a dominant element.
 *      Since the last element will be always dominant, it start
 *      in reverse order (backwards) tracking the last dominant number
 *      to save it into an array to be display later and for comparison
 *      purposes  because if a number is greater than my last dominant
 *      element, it will be dominant as well and there is no need to
 *      compare it with all the elements after.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      and the Input Array is given.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************/

public class Problem1_Tester
{
    public static final int[] INPUT_ARRAY = {16, 17, 4, 3, 28, 5, 2};
    public static final int NEXT = 1;
    public static final int INDEX_0 = 0;

    /*------------------------------ findAndSaveDominants ----------------------------
         |  Method findAndSaveDominants(int[] outputArray)
         |
         |Purpose: Finds all dominant elements in an array. Since the last element
         |  will be always dominant, it start in reverse order (backwards) tracking
         |  the last dominant number to save it in an array and for comparison
         |  purposes because if a number is greater than my last dominant element,
         |  it will be dominant as well and there is no need to compare it with all
         |  the elements after.
         |
         |  @param outputArray
         |
         | @return equals
         *-------------------------------------------------------------------*/
    private static void findAndSaveDominants(int[] outputArray)
    {
        int lastDominant = INDEX_0;
        for(int reverseIndex = (INPUT_ARRAY.length - NEXT); reverseIndex > INDEX_0; reverseIndex--)
        {
            if(INPUT_ARRAY[reverseIndex] > lastDominant)
            {
                lastDominant = INPUT_ARRAY[reverseIndex];
                outputArray[reverseIndex] = lastDominant;
            }
        }
    }

    /*------------------------------ printDominants ----------------------------
             |  Method printDominants(int[] outputArray)
             |
             |Purpose: Prints all dominant elements found on the Input Array.
             |
             |  @param outputArray
             |
             | @return equals
             *-------------------------------------------------------------------*/
    private static void printDominants(int[] outputArray)
    {
        for(int forwardIndex = INDEX_0; forwardIndex < outputArray.length; forwardIndex++)
        {
            if(outputArray[forwardIndex] != INDEX_0)
            {
                System.out.print(outputArray[forwardIndex] + " ");
            }
        }
    }


    public static void main (String[] args)
    {
        int[] outputArray = new int[INPUT_ARRAY.length];

        findAndSaveDominants(outputArray);
        printDominants(outputArray);

    }
}
