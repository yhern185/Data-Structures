/****************************************************************
 * Purpose/Description: This program implement a sub-linear running
 *      time complexity that, given an array with the properties that,
 *      the first k elements (0 < k < n-1) are in strictly increasing
 *      sequence followed by the strictly decreasing sequence. It
 *      determines whether a given integer is in the array.
 *      In order to do it, first we will use binary search to identify
 *      the breaking point from ascending to descending order, this
 *      will take a log(n) time complexity. Second it will look for the given
 *      integer using binary search on one side of the breaking point
 *      and if not found it will look on the other side. Each binary
 *      search will take log(n) time complexity keeping the total
 *      running time complexity sub-linear.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      and the ARRAY_OF_ELEMENTS is given and will have 3 or more elements.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************/

public class Problem3_Tester
{
    public static final int[] ARRAY_OF_ELEMENTS = {1,7,5,4,-2};
    public static final int GIVEN_INTEGER = -2;
    public static final int HALF = 2;
    public static final int NEXT = 1;
    public static final int INDEX_0 = 0;


    /*------------------------------ findBreakingPoint ----------------------------
         |  Method findBreakingPoint()
         |
         |Purpose: Use binary search method to identify
         |  the breaking point from ascending to descending order, this
         |  will take a log(n) complexity because it cuts the size every time.
         |
         |  @param None
         |
         | @return breakingIndex
         *-------------------------------------------------------------------*/
    private static int findBreakingPoint()
    {
        int forwardIndex = INDEX_0;
        int reverseIndex = (ARRAY_OF_ELEMENTS.length - NEXT);
        int midPoint = ((forwardIndex + reverseIndex) / HALF);
        int breakingIndex = midPoint;

        while ((ARRAY_OF_ELEMENTS[midPoint + NEXT]) > ARRAY_OF_ELEMENTS[midPoint]
                || (ARRAY_OF_ELEMENTS[midPoint - NEXT] > ARRAY_OF_ELEMENTS[midPoint]))
        {
            if(ARRAY_OF_ELEMENTS[midPoint - NEXT] > ARRAY_OF_ELEMENTS[midPoint])
            {
                reverseIndex = midPoint;
                midPoint = ((forwardIndex + reverseIndex) / HALF);
                breakingIndex = midPoint;
            }
            else
            {
                forwardIndex = midPoint;
                midPoint = ((forwardIndex + reverseIndex) / HALF);
                breakingIndex = midPoint;
            }
        }
        return breakingIndex;
    }

    /*------------------------------ searchOnLeftSide ----------------------------
         |  Method searchOnLeftSide(int breakingPointIndex)
         |
         |Purpose: Use binary search method to see if a given integer is found.
         |  This side of the array is already sorted in ascending order, method
         |  uses binary search, this will take a log(n) complexity because it cuts the
         |  size every time. Return true if integer is found, false otherwise.
         |
         |  @param breakingPointIndex
         |
         | @return found
         *-------------------------------------------------------------------*/
    private static boolean searchOnLeftSide(int breakingPointIndex)
    {
        int forwardIndex = INDEX_0;
        int reverseIndex = breakingPointIndex;
        boolean found = false;

        while(reverseIndex > forwardIndex)
        {
            int midPoint = ((forwardIndex + reverseIndex) / HALF);
            if((GIVEN_INTEGER == ARRAY_OF_ELEMENTS[midPoint])
                    || GIVEN_INTEGER == ARRAY_OF_ELEMENTS[forwardIndex]
                    || GIVEN_INTEGER == ARRAY_OF_ELEMENTS[reverseIndex])
            {
                found = true;
                forwardIndex = reverseIndex;
            }
            else if(GIVEN_INTEGER > ARRAY_OF_ELEMENTS[midPoint])
            {
                forwardIndex = midPoint + NEXT;
            }
            else
            {
                reverseIndex = midPoint - NEXT;
            }
        }
        return found;
    }

    /*------------------------------ searchOnRightSide ----------------------------
         |  Method searchOnLeftSide(int breakingPointIndex)
         |
         |Purpose: Use binary search method to see if a given integer is found.
         |  This side of the array is already sorted in descending order, method
         |  uses binary search, this will take a log(n) complexity because it cuts the
         |  size every time. Return true if integer is found, false otherwise.
         |
         |  @param breakingPointIndex
         |
         | @return found
         *-------------------------------------------------------------------*/
    private static boolean searchOnRightSide(int breakingPointIndex)
    {
        int forwardIndex = breakingPointIndex;
        int reverseIndex = (ARRAY_OF_ELEMENTS.length - NEXT);
        boolean found = false;

        while(reverseIndex > forwardIndex)
        {
            int midPoint = ((forwardIndex + reverseIndex) / HALF);
            if((GIVEN_INTEGER == ARRAY_OF_ELEMENTS[midPoint])
                    || GIVEN_INTEGER == ARRAY_OF_ELEMENTS[forwardIndex]
                    || GIVEN_INTEGER == ARRAY_OF_ELEMENTS[reverseIndex])
            {
                found = true;
                forwardIndex = reverseIndex;
            }
            else if(GIVEN_INTEGER > ARRAY_OF_ELEMENTS[midPoint])
            {
                reverseIndex = midPoint - NEXT;
            }
            else
            {
                forwardIndex = midPoint + NEXT;
            }
        }
        return found;
    }

    /*------------------------------ isFound ----------------------------
             |  Method isFound(int breakingPointIndex)
             |
             |Purpose: Checks is the number at the breaking point index is the one
             |  we are trying to find. In positive case case returns true, otherwise
             |  go to the left side of array (ascending sorted side) to find it there).
             |  If number is not found there go to the right side of the array
             |  (descending order to look for it) if it is found returns true, false
             |  otherwise.
             |
             |  @param breakingPointIndex
             |
             | @return found
             *-------------------------------------------------------------------*/
    private static boolean isFound(int breakingPointIndex)
    {
        boolean found = false;
        if(GIVEN_INTEGER == ARRAY_OF_ELEMENTS[breakingPointIndex])
        {
            found = true;
        }
        else
        {
            found = searchOnLeftSide(breakingPointIndex);
        }
        if(!found)
        {
            found = searchOnRightSide(breakingPointIndex);
        }
        return found;
    }


    public static void main (String[] args)
    {
        int breakingPointIndex = findBreakingPoint();
        boolean found = isFound(breakingPointIndex);

        System.out.println("GIVEN INTEGER " + GIVEN_INTEGER + " is found? " + found);
    }
}
