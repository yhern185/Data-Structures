/****************************************************************
 * Purpose/Description: This program implements a recursive boolean
 *      function that returns True if a given array contents remain
 *      the same when array is reversed, i.e., when last element is
 *      equal to the first element, second last element is equal to
 *      the second element and so on. Otherwise return False.
 *      Use a recursive method making the problem an smaller problem
 *      of the same type until it reach a base case. Tracks two
 *      pointers, one and the beginning of the array and one at the
 *      end. They will be updating on every iteration until they are
 *      the same or overlaps.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      and the Input Array is given.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************/

public class Problem2_Tester
{
    public static final int INDEX_0 = 0;
    public static final int NEXT = 1;
    public static final int[] INPUT_ARRAY = {12, 32, 67, 32, 12};


    /*------------------------------ verify ----------------------------
         |  Method verify(int forwardIndex, int reverseIndex)
         |
         |Purpose: Finds if the fixed numbers in a certain array are
         |  the same in forward and backward order using a recursive method
         |  making the problem an smaller problem of the same type until
         |  it reach a base case.
         |
         |  @param forwardIndex
         |  @param reverseIndex
         |
         | @return equals
         *-------------------------------------------------------------------*/
    private static boolean verify(int forwardIndex, int reverseIndex)
    {
        boolean equals = false;
        if(forwardIndex >= reverseIndex)
        {
            equals = true;
        }
        else
        {
            int straightNumber = INPUT_ARRAY[forwardIndex];
            int reverseNumber = INPUT_ARRAY[reverseIndex];

            if(straightNumber == reverseNumber)
            {
                equals = verify((forwardIndex + NEXT), (reverseIndex - NEXT));
            }
        }
        return equals;
    }


    public static void main (String[] args)
    {

        int forwardIndex = INDEX_0;
        int reverseIndex = (INPUT_ARRAY.length - NEXT);

        System.out.println(verify(forwardIndex, reverseIndex));
    }
}
