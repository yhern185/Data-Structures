import java.util.ArrayList;

/*************************************************************************
 * Purpose/Description: This program implement Implement a program in Java
 *      that, given an array of integers, places all positive elements at
 *      the end of the array without changing the relative order of positive
 *      and negative elements. Your program must have O(n) running time
 *      complexity and O(n) auxiliary space complexity.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      the Input Array is given and is not empty and they is no 0 in the array.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************************/

public class Problem4_Tester
{
    public static final int[] INPUT_ARRAY = {1, -1, -3, -2, 7, 5, -11, 6, -10};
    public static final int INDEX_0 = 0;


    /*------------------------------ savePositivesNumbers ----------------------------
         |  Method savePositivesNumbers(ArrayList<Integer> organizedIntegers)
         |
         |Purpose: Save all positive numbers of an array into an auxiliary array.
         |
         |  @param organizedIntegers
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void savePositivesNumbers(ArrayList<Integer> organizedIntegers)
    {
        for(int indexCounter = INDEX_0; indexCounter < INPUT_ARRAY.length; indexCounter++)
        {
            if(INPUT_ARRAY[indexCounter] > INDEX_0)
            {
                organizedIntegers.add(INPUT_ARRAY[indexCounter]);
            }
        }
    }

    /*------------------------------ saveNegativeNumbers ----------------------------
         |  Method saveNegativeNumbers(ArrayList<Integer> positiveIntegers)
         |
         |Purpose: Save all negative integers of an array into an auxiliary array.
         |
         |  @param organizedIntegers
         |
         | @return None
         *-------------------------------------------------------------------*/
    private static void saveNegativeNumbers(ArrayList<Integer> organizedIntegers)
    {
        for(int indexCounter = INDEX_0; indexCounter < INPUT_ARRAY.length; indexCounter++)
        {
            if(INPUT_ARRAY[indexCounter] < INDEX_0)
            {
                organizedIntegers.add(INPUT_ARRAY[indexCounter]);
            }
        }
    }


    public static void main (String[] args)
    {
        ArrayList<Integer> organizedIntegers = new ArrayList<>();

        saveNegativeNumbers(organizedIntegers);
        savePositivesNumbers(organizedIntegers);
        System.out.println(organizedIntegers.toString());
    }
}
