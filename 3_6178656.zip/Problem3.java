/**************************************************************************
 * Purpose/Description: This program accepts a sorted array of N distinct
 *  integers that has been rotated an unknown number of times. Then
 *  Implements an efficient algorithm that finds an element in the array.
 *  Since we know the array was initially sorted we will use a binary
 *  search to find the requested number, but since the array has been
 *  rotated an unknown of times it is necessary to go through it to find
 *  the breaking point.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      and the Input Array is given, and the array was originally sorted
 *      in increasing order.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************************/

public class Problem3
{
    public static final int INDEX_0 = 0;
    public static final int HALF = 2;
    public static final int NEXT = 1;
    public static final int[] INPUT_ARRAY = {15, 16, 19, 20, 25, 1, 3, 4, 5, 7, 10, 14};
    public static final int FIND = 5;
    public static final int NO_INDEX = -1;

    public static void main(String[] args)
    {
        int minIndex = findMinIndex();
        findNumber(minIndex);
    }

    /**------------------------------ findNumber ----------------------------
     |  Method findNumber(int minIndex)
     |
     |Purpose: Method uses a binary search to find the number based on the
     |  minimum number index because from that point to the right all numbers
     |  will be greater sorted in increasing order. And to the left of that
     |  point the numbers will be greater in decreasing order.
     |
     |  @param minIndex
     |
     | @return none
     *-------------------------------------------------------------------**/
    private static void findNumber(int minIndex)
    {
        int foundIndex = NO_INDEX;
        if(FIND == INPUT_ARRAY[minIndex])
        {
            foundIndex = minIndex;
        }
        else
        {
            foundIndex = searchOnLeftSide(minIndex);
            if(foundIndex == NO_INDEX)
            {
                foundIndex = searchOnRightSide(minIndex);
            }
        }

        if(foundIndex != NO_INDEX)
        {
            System.out.println(foundIndex + " (the index of " + FIND + " in the array)");
        }
        else
        {
            System.out.println("Number " + FIND + " not found in the array.");
        }
    }

    /**------------------------------ searchOnRightSide ----------------------------
         |  Method searchOnRightSide(int minIndex)
         |
         |Purpose: Use binary search method to see if a given integer is found.
         |  This side of the array is already sorted in ascending order. Method
         |  uses binary search, this will take a log(n) complexity because it cuts the
         |  size every time. Return true if integer is found, false otherwise.
         |
         |  @param breakingPointIndex
         |
         | @return found
         *-------------------------------------------------------------------*/
    private static int searchOnRightSide(int minIndex)
    {
        int forwardIndex = minIndex + NEXT;
        int reverseIndex = (INPUT_ARRAY.length - NEXT);
        int foundIndex = NO_INDEX;

        while(reverseIndex > forwardIndex)
        {
            int midPoint = ((forwardIndex + reverseIndex) / HALF);
            if((FIND == INPUT_ARRAY[midPoint])
                    || FIND == INPUT_ARRAY[forwardIndex]
                    || FIND == INPUT_ARRAY[reverseIndex])
            {
                if(INPUT_ARRAY[midPoint] == FIND)
                {
                    foundIndex = midPoint;
                }
                else if(FIND == INPUT_ARRAY[forwardIndex])
                {
                    foundIndex = forwardIndex;
                }
                else
                {
                    foundIndex = reverseIndex;
                }
                forwardIndex = reverseIndex;
            }
            else if(FIND > INPUT_ARRAY[midPoint])
            {
                forwardIndex = midPoint + NEXT;
            }
            else
            {
                reverseIndex = midPoint - NEXT;
            }
        }
        return foundIndex;
    }

    /**------------------------------ searchOnLeftSide ----------------------------
         |  Method searchOnLeftSide(int minIndex)
         |
         |Purpose: Use binary search method to see if a given integer is found.
         |  This side of the array is already sorted in ascending order, method
         |  uses binary search, this will take a log(n) complexity because it cuts the
         |  size every time. Return true if integer is found, false otherwise.
         |
         |  @param minIndex
         |
         | @return found
         *-------------------------------------------------------------------*/
    private static int searchOnLeftSide(int minIndex)
    {
        int forwardIndex = INDEX_0;
        int reverseIndex = minIndex - NEXT;
        int foundIndex = NO_INDEX;

        while(reverseIndex > forwardIndex)
        {
            int midPoint = ((forwardIndex + reverseIndex) / HALF);
            if((FIND == INPUT_ARRAY[midPoint])
                    || FIND == INPUT_ARRAY[forwardIndex]
                    || FIND == INPUT_ARRAY[reverseIndex])
            {
                if(INPUT_ARRAY[midPoint] == FIND)
                {
                    foundIndex = midPoint;
                }
                else if(FIND == INPUT_ARRAY[forwardIndex])
                {
                    foundIndex = forwardIndex;
                }
                else
                {
                    foundIndex = reverseIndex;
                }
                forwardIndex = reverseIndex;
            }
            else if(FIND > INPUT_ARRAY[midPoint])
            {
                forwardIndex = midPoint + NEXT;
            }
            else
            {
                reverseIndex = midPoint - NEXT;
            }
        }
        return foundIndex;
    }

    /**------------------------------ findMinIndex ----------------------------
     |  Method findMinIndex()
     |
     |Purpose: Based on the fact that the array was initially sorted in increasing
     |  order, this method will find the index for the minimum number in the
     |  array because from that point to the right all numbers will be greater
     |  sorted in increasing order. And to the left of that point the numbers
     |  will be greater in decreasing order.
     |
     |  @param none
     |
     | @return minIndex
     *-------------------------------------------------------------------**/
    private static int findMinIndex()
    {
        int forwardIndex = INDEX_0;
        int reverseIndex = (INPUT_ARRAY.length - NEXT);
        int midPoint = ((forwardIndex + reverseIndex) / HALF);

        return getMinIndex(forwardIndex, midPoint, reverseIndex);
    }

    /**------------------------------ getMinIndex ----------------------------
     |  Method getMinIndex(int forwardIndex, int midPoint, int reverseIndex)
     |
     |Purpose: Methods find the breaking point (index position that identifies
     |  the minimum number in the array) on a recursive way using a binary search
     |  by cutting the size of the problem in every step.
     |  The minimum element is the only element whose previous is greater than it.
     |  If there is no previous element element, then first element is minimum.
     |  We check this condition for middle element by comparing it with previous
     |  and post elements. If minimum element is not at middle, then minimum
     |  element lies in either left half or right half. If middle element is
     |  smaller than last element, then the minimum element lies in left half
     |  Else minimum element lies in right half.
     |
     |  @param forwardIndex
     |  @param midPoint
     |  @param reverseIndex
     |
     | @return midPoint
     *-------------------------------------------------------------------**/
    private static int getMinIndex(int forwardIndex, int midPoint, int reverseIndex)
    {
        if((midPoint == INPUT_ARRAY.length - NEXT) || (midPoint == INDEX_0))
        {
            return midPoint;
        }

        if((INPUT_ARRAY[midPoint] < INPUT_ARRAY[midPoint + NEXT]) &&
                (INPUT_ARRAY[midPoint] < INPUT_ARRAY[midPoint - NEXT]))
        {
            return midPoint;
        }
        if(INPUT_ARRAY[midPoint] < INPUT_ARRAY[INPUT_ARRAY.length - NEXT])
        {
            reverseIndex = midPoint;
            midPoint = ((forwardIndex + reverseIndex) / HALF);
            midPoint = getMinIndex(forwardIndex, midPoint, reverseIndex);
        }
        else
        {
            forwardIndex = midPoint;
            midPoint = ((forwardIndex + reverseIndex) / HALF);
            midPoint = getMinIndex(forwardIndex, midPoint, reverseIndex);
        }
        return midPoint;
    }

    /**------------------------------ Subsection B ----------------------------
     |  What is the running time complexity of your algorithm?
     |
     |      The running time complexity will be O(log(n) because the program
     |  uses binary search to find the index number on each side
     |  of the breaking number O(log(n)). And It takes O(log(n)) to find the
     |  minimum index number in the array. So the total time complexity will
     |  be O(log(n))
     *-------------------------------------------------------------------**/
}
