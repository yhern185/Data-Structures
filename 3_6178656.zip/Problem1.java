/****************************************************************
 * Purpose/Description: This program accepts an unsorted array of
 *  n integers numbers (with possible duplicates) in range [1..k].
 *  Implement in Java an algorithm that preprocesses the input array
 *  in O(n+k) running time and then returns how many integer numbers
 *  there are in the range [left..right] in O(1) running time for
 *  any given left and right, 1 <= left <= right <= k.
 *
 *      **Note**
 *      This program works assuming no input validation is required,
 *      the Input Array is given and the max integer is given.
 *
 * Author’s Panther ID: 6178656
 *
 * Certification:
 *      I hereby certify that this work is my own and none of
 *      it is the work of any other person.
 ***************************************************************/

public class Problem1
{
    public static final int INDEX_0 = 0;
    public static final int UNIT = 1;

    public static void main (String[] args)
    {
        int[] inputArray = {3, 8, 2, 4, 1, 9, 11, 4, 15};
        int maxInteger = 15;
        int lowerValue = 2;
        int upperValue = 9;

        int [] numberOccurrences = preProcessInput(inputArray, maxInteger);
        amountOfElements(numberOccurrences, lowerValue, upperValue);
    }

    /**------------------------------ amountOfElements ----------------------------
     |  Method amountOfElements(int[] numberOccurrences, int lowerValue, int upperValue)
     |
     |Purpose: Using the helper array and an upper and lower bound number this method
     |  will determine the amount of integers in between those two numbers are found
     |  in the original unsorted array. It adds 1 to the difference between the bound to
     |  include the upper bound.
     |
     |  @param numberOccurrences
     |  @param lowerValue
     |  @param upperValue
     |
     | @return numberOccurrences
     *-------------------------------------------------------------------**/
    private static void amountOfElements(int[] numberOccurrences, int lowerValue, int upperValue)
    {
        int amountOfIntegers = numberOccurrences[upperValue] - numberOccurrences[lowerValue];
        amountOfIntegers++;
        System.out.println("Total number in range [" + lowerValue + ".." + upperValue + "] is "
                            + amountOfIntegers);
    }

    /**------------------------------ preProcessInput ----------------------------
         |  Method preProcessInput(int[] inputArray, int maxInteger)
         |
         |Purpose: Uses a helper array to save the occurrences of the numbers on the
         |  unsorted input array. After that recurs the helper array assigning values
         |  in the order they appear considering the amount of elements before them.
         |
         |  @param inputArray
         |  @param maxInteger
         |
         | @return numberOccurrences
         *-------------------------------------------------------------------**/
    private static int[] preProcessInput(int[] inputArray, int maxInteger)
    {
        int[] numberOccurrences = new int[maxInteger + UNIT];
        int occurrencesCounter = INDEX_0;
        for(int inputArrayIndex = INDEX_0; inputArrayIndex < inputArray.length; inputArrayIndex++)
        {
            numberOccurrences[inputArray[inputArrayIndex]]++;
        }
        for(int numberOccurrencesIndex = INDEX_0; numberOccurrencesIndex < numberOccurrences.length;
            numberOccurrencesIndex++)
        {
            if(numberOccurrences[numberOccurrencesIndex] != INDEX_0)
            {
                numberOccurrences[numberOccurrencesIndex] += occurrencesCounter;
                occurrencesCounter = numberOccurrences[numberOccurrencesIndex];
            }
            else
            {
                numberOccurrences[numberOccurrencesIndex] = occurrencesCounter;
            }
        }
        return numberOccurrences;
    }
}
